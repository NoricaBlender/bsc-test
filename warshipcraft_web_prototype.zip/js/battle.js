import * as THREE from 'three';
import * as CANNON from 'cannon-es';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { PARTS, GRID, CELL, WATERLINE_Y, defaultShip } from './builder.js';
import { clamp, lerp, isTouchDevice, makeKey, parseKey } from './utils.js';

const FIXED_DT = 1/60;

function buildCompoundFromBlocks(blocks){
  // Returns { body, meta } where meta contains block world offsets and types
  const body = new CANNON.Body({ mass: 1 });
  const meta = [];

  let totalMass = 0;
  const cm = new CANNON.Vec3(0,0,0);

  // Pre-pass: compute centre of mass (weighted by part mass)
  for (const [key, type] of Object.entries(blocks)){
    const {x,y,z} = parseKey(key);
    const m = PARTS[type].mass;
    const px = (x + 0.5) * CELL;
    const py = (z + 0.5) * CELL;
    const pz = (y + 0.5) * CELL;
    totalMass += m;
    cm.x += px * m; cm.y += py * m; cm.z += pz * m;
  }
  if (totalMass <= 0.0001){
    totalMass = 1;
    cm.set(0,0,0);
  } else {
    cm.x /= totalMass; cm.y /= totalMass; cm.z /= totalMass;
  }

  // Add shapes as boxes into compound, shifted so CM is near origin
  const half = new CANNON.Vec3(CELL/2, CELL/2, CELL/2);
  const box = new CANNON.Box(half);

  for (const [key, type] of Object.entries(blocks)){
    const {x,y,z} = parseKey(key);
    const m = PARTS[type].mass;

    const px = (x + 0.5) * CELL - cm.x;
    const py = (z + 0.5) * CELL - cm.y;
    const pz = (y + 0.5) * CELL - cm.z;

    // cannon-es does not support per-shape mass; approximate by distributing mass in body.
    body.addShape(box, new CANNON.Vec3(px,py,pz));
    meta.push({ offset: new CANNON.Vec3(px,py,pz), type });
  }

  body.mass = totalMass;
  body.updateMassProperties();

  return { body, meta, centerOfMass: cm, totalMass };
}

function makeShipMesh(blocks){
  const group = new THREE.Group();
  const boxGeo = new THREE.BoxGeometry(CELL, CELL, CELL);

  const mats = {};
  for (const [type, info] of Object.entries(PARTS)){
    mats[type] = new THREE.MeshStandardMaterial({ color: info.color, roughness:0.7, metalness:0.12 });
  }

  for (const [key, type] of Object.entries(blocks)){
    const {x,y,z} = parseKey(key);
    const mesh = new THREE.Mesh(boxGeo, mats[type]);
    mesh.position.set((x+0.5)*CELL, (z+0.5)*CELL, (y+0.5)*CELL);
    group.add(mesh);
  }
  return group;
}

function computeShipStats(blocks){
  let mass=0, buoy=0, thrust=0, fire=0, count=0;
  for (const type of Object.values(blocks)){
    const p = PARTS[type];
    count++;
    mass += p.mass;
    buoy += p.buoy;
    thrust += p.thrust;
    fire += p.fire;
  }
  return { mass, buoy, thrust, fire, count };
}

function makeOcean(scene){
  const geo = new THREE.PlaneGeometry(400,400,64,64);
  const mat = new THREE.MeshStandardMaterial({ color: 0x07345f, transparent:true, opacity:0.55, roughness:0.25, metalness:0.0 });
  const mesh = new THREE.Mesh(geo, mat);
  mesh.rotation.x = -Math.PI/2;
  mesh.position.y = WATERLINE_Y;
  scene.add(mesh);
  return mesh;
}

function addSky(scene){
  const geo = new THREE.SphereGeometry(300, 32, 16);
  const mat = new THREE.MeshBasicMaterial({ color: 0x09142b, side: THREE.BackSide });
  const sky = new THREE.Mesh(geo, mat);
  scene.add(sky);
}

function cannonVec3ToThree(v){ return new THREE.Vector3(v.x,v.y,v.z); }

class Projectile {
  constructor(world, scene, pos, vel){
    this.body = new CANNON.Body({ mass: 0.2, shape: new CANNON.Sphere(0.18) });
    this.body.position.copy(pos);
    this.body.velocity.copy(vel);
    this.body.linearDamping = 0.02;
    world.addBody(this.body);

    const geo = new THREE.SphereGeometry(0.18, 10, 10);
    const mat = new THREE.MeshStandardMaterial({ color: 0xffd27a, roughness:0.3, metalness:0.1 });
    this.mesh = new THREE.Mesh(geo, mat);
    scene.add(this.mesh);

    this.life = 0;
  }
  step(dt){
    this.life += dt;
    this.mesh.position.copy(cannonVec3ToThree(this.body.position));
  }
  isDead(){ return this.life > 4.0; }
  dispose(world, scene){
    world.removeBody(this.body);
    scene.remove(this.mesh);
  }
}

export class BattleApp {
  constructor({canvas, store}){
    this.canvas = canvas;
    this.store = store;

    this.scene = null;
    this.camera = null;
    this.renderer = null;
    this.controls = null;

    this.world = null;
    this.clock = new THREE.Clock();

    this.player = null; // {body, mesh, meta, stats, hp}
    this.enemy = null;

    this.projectiles = [];
    this.input = { forward:0, turn:0, fire:false, aimX:0, aimY:0 };

    this.hudHp = document.getElementById('hudHp');
    this.hudEnemyHp = document.getElementById('hudEnemyHp');

    // mobile
    this.mobile = { active:false, stick: {x:0,y:0} };
    this.btnFire = document.getElementById('btnFire');
    this.stick = document.getElementById('stick');
    this.stickKnob = document.getElementById('stickKnob');
  }

  init(){
    this._initThree();
    this._initPhysics();
    this._initInput();
    this._resize();
    window.addEventListener('resize', () => this._resize());
    this.useDemoShip();
    this._loop();
  }

  _initThree(){
    const scene = new THREE.Scene();
    scene.fog = new THREE.Fog(0x0b1220, 20, 180);

    const camera = new THREE.PerspectiveCamera(60, 1, 0.1, 500);
    camera.position.set(0, 14, 22);

    const renderer = new THREE.WebGLRenderer({ canvas: this.canvas, antialias:true, alpha:true });
    renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;

    const controls = new OrbitControls(camera, this.canvas);
    controls.enableDamping = true;
    controls.enablePan = false;
    controls.minDistance = 10;
    controls.maxDistance = 60;

    const hemi = new THREE.HemisphereLight(0x9bb7ff, 0x08101f, 0.95);
    scene.add(hemi);
    const dir = new THREE.DirectionalLight(0xffffff, 0.8);
    dir.position.set(10,24,8);
    scene.add(dir);

    addSky(scene);
    makeOcean(scene);

    // simple islands
    const islandGeo = new THREE.CylinderGeometry(6, 10, 3, 18);
    const islandMat = new THREE.MeshStandardMaterial({ color: 0x1d3a22, roughness:0.9 });
    const island = new THREE.Mesh(islandGeo, islandMat);
    island.position.set(-40, -1.0, -25);
    scene.add(island);

    this.scene = scene;
    this.camera = camera;
    this.renderer = renderer;
    this.controls = controls;
  }

  _initPhysics(){
    const world = new CANNON.World({
      gravity: new CANNON.Vec3(0, -9.82, 0),
    });
    world.broadphase = new CANNON.SAPBroadphase(world);
    world.allowSleep = true;

    // Ocean surface is not a collider; we do buoyancy forces manually.

    this.world = world;
  }

  _initInput(){
    const keys = new Set();
    window.addEventListener('keydown', (e) => {
      keys.add(e.code);
      if (e.code === 'Space') e.preventDefault();
    });
    window.addEventListener('keyup', (e) => keys.delete(e.code));

    // aim with pointer (also used for touch to “look”)
    const onAim = (ev) => {
      const rect = this.canvas.getBoundingClientRect();
      const nx = (ev.clientX - rect.left) / rect.width;
      const ny = (ev.clientY - rect.top) / rect.height;
      this.input.aimX = nx;
      this.input.aimY = ny;
    };
    this.canvas.addEventListener('pointermove', onAim);
    this.canvas.addEventListener('pointerdown', onAim);

    // mobile controls
    const touch = isTouchDevice();
    this.mobile.active = touch;
    if (touch){
      const stickRect = () => this.stick.getBoundingClientRect();
      const setKnob = (x,y) => {
        const r = stickRect();
        const cx = r.left + r.width/2;
        const cy = r.top + r.height/2;
        const dx = clamp(x - cx, -r.width/2, r.width/2);
        const dy = clamp(y - cy, -r.height/2, r.height/2);
        const nx = dx / (r.width/2);
        const ny = dy / (r.height/2);
        const len = Math.hypot(nx,ny);
        const k = len > 1 ? 1/len : 1;
        this.mobile.stick.x = nx * k;
        this.mobile.stick.y = ny * k;

        this.stickKnob.style.left = `${50 + this.mobile.stick.x*40}%`;
        this.stickKnob.style.top  = `${50 + this.mobile.stick.y*40}%`;
      };

      let active = false;
      const onDown = (e) => { active = true; this.stick.setPointerCapture(e.pointerId); setKnob(e.clientX, e.clientY); };
      const onMove = (e) => { if(active) setKnob(e.clientX, e.clientY); };
      const onUp = () => {
        active = false;
        this.mobile.stick.x = 0; this.mobile.stick.y = 0;
        this.stickKnob.style.left = '50%'; this.stickKnob.style.top = '50%';
      };
      this.stick.addEventListener('pointerdown', onDown);
      this.stick.addEventListener('pointermove', onMove);
      this.stick.addEventListener('pointerup', onUp);
      this.stick.addEventListener('pointercancel', onUp);

      this.btnFire.addEventListener('pointerdown', () => this.input.fire = true);
      this.btnFire.addEventListener('pointerup', () => this.input.fire = false);
      this.btnFire.addEventListener('pointercancel', () => this.input.fire = false);
    }

    // per-frame update of movement input
    this._updateInput = () => {
      if (this.mobile.active){
        this.input.forward = -this.mobile.stick.y; // up is negative y
        this.input.turn = this.mobile.stick.x;
      } else {
        this.input.forward = (keys.has('KeyW')?1:0) + (keys.has('ArrowUp')?1:0) - (keys.has('KeyS')?1:0) - (keys.has('ArrowDown')?1:0);
        this.input.turn = (keys.has('KeyD')?1:0) + (keys.has('ArrowRight')?1:0) - (keys.has('KeyA')?1:0) - (keys.has('ArrowLeft')?1:0);
        this.input.fire = keys.has('Space');
      }
    };
  }

  _resize(){
    const rect = this.canvas.getBoundingClientRect();
    const w = Math.max(2, Math.floor(rect.width));
    const h = Math.max(2, Math.floor(rect.height));
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h, false);
  }

  respawn(){
    if (!this.player) return;
    this._resetMatch(this.player._sourceBlocks, this.enemy? this.enemy._sourceBlocks : null);
  }

  useDemoShip(){
    const demo = defaultShip();
    this._resetMatch(demo.blocks, null);
  }

  useSavedShip(){
    const ship = this.store.load();
    if (ship && ship.blocks){
      this._resetMatch(ship.blocks, null);
    } else {
      this.useDemoShip();
    }
  }

  _resetMatch(playerBlocks, enemyBlocks){
    // Clean up existing
    for (const p of this.projectiles) p.dispose(this.world, this.scene);
    this.projectiles = [];

    if (this.player){
      this.world.removeBody(this.player.body);
      this.scene.remove(this.player.mesh);
    }
    if (this.enemy){
      this.world.removeBody(this.enemy.body);
      this.scene.remove(this.enemy.mesh);
    }

    this.player = this._spawnShip(playerBlocks, new CANNON.Vec3(0, 2.5, 0), true);
    const enemyDemo = enemyBlocks || this._makeEnemyShip();
    this.enemy = this._spawnShip(enemyDemo, new CANNON.Vec3(14, 2.5, -12), false);

    this.player._sourceBlocks = playerBlocks;
    this.enemy._sourceBlocks = enemyDemo;

    this.controls.target.copy(this.player.mesh.position);
  }

  _makeEnemyShip(){
    // A slightly larger target with armour and fewer engines
    const blocks = {};
    for (let x=6; x<16; x++){
      for (let y=4; y<9; y++){
        blocks[makeKey(x,y,0)] = 'hull';
      }
    }
    // armour belt
    for (let x=6; x<16; x++){
      blocks[makeKey(x,4,0)] = 'armor';
      blocks[makeKey(x,8,0)] = 'armor';
    }
    blocks[makeKey(8,6,0)] = 'engine';
    blocks[makeKey(13,6,1)] = 'cannon';
    blocks[makeKey(14,6,1)] = 'cannon';
    return blocks;
  }

  _spawnShip(blocks, pos, isPlayer){
    const stats = computeShipStats(blocks);
    const { body, meta, centerOfMass, totalMass } = buildCompoundFromBlocks(blocks);

    body.position.copy(pos);
    body.linearDamping = 0.12;
    body.angularDamping = 0.35;
    body.quaternion.setFromEuler(0, isPlayer ? 0 : Math.PI*0.75, 0);

    // material tuning
    body.sleepSpeedLimit = 0.2;
    body.sleepTimeLimit = 0.7;

    this.world.addBody(body);

    const mesh = makeShipMesh(blocks);
    mesh.position.copy(cannonVec3ToThree(body.position));
    this.scene.add(mesh);

    // health approx: armour blocks add more
    let hp = 50 + stats.count * 6 + Object.values(blocks).filter(t => t==='armor').length * 4;
    hp = clamp(hp, 80, 240);

    return { body, mesh, meta, stats, hp, isPlayer, centerOfMass, totalMass };
  }

  _loop(){
    requestAnimationFrame(() => this._loop());

    const dt = Math.min(0.05, this.clock.getDelta());
    this._updateInput();
    this._step(dt);

    this.controls.update();
    this.renderer.render(this.scene, this.camera);
  }

  _step(dt){
    if (!this.player || !this.enemy) return;

    // step with fixed timestep for stability
    let t = dt;
    while (t > 0){
      const step = Math.min(FIXED_DT, t);
      this._applyForces(this.player, step, true);
      this._applyForces(this.enemy, step, false);

      this.world.step(step);

      // sync meshes
      this._syncShipMesh(this.player);
      this._syncShipMesh(this.enemy);

      // projectiles
      for (const p of this.projectiles) p.step(step);
      this._handleHits();

      // cleanup
      for (let i=this.projectiles.length-1; i>=0; i--){
        if (this.projectiles[i].isDead()){
          this.projectiles[i].dispose(this.world, this.scene);
          this.projectiles.splice(i,1);
        }
      }

      t -= step;
    }

    // camera follows player gently
    const target = this.player.mesh.position.clone();
    this.controls.target.lerp(target, 0.08);

    // HUD
    this.hudHp.textContent = String(Math.max(0, Math.floor(this.player.hp)));
    this.hudEnemyHp.textContent = String(Math.max(0, Math.floor(this.enemy.hp)));
  }

  _syncShipMesh(ship){
    ship.mesh.position.copy(cannonVec3ToThree(ship.body.position));
    ship.mesh.quaternion.copy(new THREE.Quaternion(ship.body.quaternion.x, ship.body.quaternion.y, ship.body.quaternion.z, ship.body.quaternion.w));
  }

  _applyForces(ship, dt, isPlayer){
    // --- buoyancy model (simple but effective for a prototype)
    // For each block centre, if below waterline apply upward force proportional to submersion depth.
    const kLift = 22.0;          // lift stiffness
    const kDamp = 3.0;           // vertical damping
    const kDrag = 1.1;           // horizontal drag

    const body = ship.body;

    for (const b of ship.meta){
      // world position of block centre
      const wp = body.pointToWorldFrame(b.offset);
      const depth = WATERLINE_Y - wp.y;

      if (depth > 0){
        const buoyFactor = PARTS[b.type].buoy; // “floatiness”
        const lift = kLift * depth * buoyFactor;
        // damping against vertical velocity
        const v = body.getVelocityAtWorldPoint(wp);
        const damp = -kDamp * v.y;

        const force = new CANNON.Vec3(0, lift + damp, 0);
        body.applyForce(force, wp);
      }
    }

    // quadratic-ish drag against velocity (keeps ships controllable)
    const v = body.velocity;
    const drag = new CANNON.Vec3(-v.x * Math.abs(v.x) * kDrag, 0, -v.z * Math.abs(v.z) * kDrag);
    body.applyForce(drag, body.position);

    // keep roll/pitch from exploding (arcade stabiliser)
    const q = body.quaternion;
    const euler = new CANNON.Vec3();
    q.toEuler(euler, 'YZX'); // approximate
    const roll = euler.z;
    const pitch = euler.x;
    body.torque.x += (-pitch) * 8.0;
    body.torque.z += (-roll) * 8.0;

    // thrust + steering
    const thrustPower = ship.stats.thrust * 9.0;
    const turnPower = 2.4;

    let forward = 0, turn = 0;
    if (isPlayer){
      forward = clamp(this.input.forward, -1, 1);
      turn = clamp(this.input.turn, -1, 1);

      if (this.input.fire) this._tryFire(ship);
    } else {
      // enemy AI: face player and push forward
      const toPlayer = this.player.body.position.vsub(ship.body.position);
      const desired = Math.atan2(toPlayer.x, toPlayer.z);
      const current = this._yawFromQuat(ship.body.quaternion);
      let delta = desired - current;
      while (delta > Math.PI) delta -= Math.PI*2;
      while (delta < -Math.PI) delta += Math.PI*2;
      turn = clamp(delta * 1.4, -1, 1);
      forward = 0.7;

      // shoot if roughly aligned and in range
      const dist = toPlayer.length();
      if (dist < 55 && Math.abs(delta) < 0.35){
        if (Math.random() < 0.04) this._tryFire(ship);
      }
    }

    const localFwd = new CANNON.Vec3(0,0,1);
    const worldFwd = body.vectorToWorldFrame(localFwd);
    const thrust = worldFwd.scale(thrustPower * forward);
    body.applyForce(thrust, body.position);

    body.angularVelocity.y += turn * turnPower * dt;
  }

  _yawFromQuat(q){
    // yaw around Y for an upright-ish body
    const ysqr = q.y * q.y;
    const t3 = +2.0 * (q.w * q.y + q.z * q.x);
    const t4 = +1.0 - 2.0 * (ysqr + q.z * q.z);
    return Math.atan2(t3, t4);
  }

  _tryFire(ship){
    const now = performance.now();
    if (!ship._nextFire) ship._nextFire = 0;
    if (now < ship._nextFire) return;
    ship._nextFire = now + 220; // ms

    const cannonCount = Object.values(ship.meta).filter(b => b.type === 'cannon').length;
    if (cannonCount <= 0) return;

    // pick a cannon block near the front (best effort)
    let chosen = null;
    for (const b of ship.meta){
      if (b.type !== 'cannon') continue;
      if (!chosen || b.offset.z > chosen.offset.z) chosen = b;
    }
    chosen = chosen || ship.meta.find(b => b.type==='cannon');
    if (!chosen) return;

    const muzzleLocal = chosen.offset.vadd(new CANNON.Vec3(0, 0.1, CELL*0.65));
    const muzzle = ship.body.pointToWorldFrame(muzzleLocal);

    const fwd = ship.body.vectorToWorldFrame(new CANNON.Vec3(0,0,1));
    const vel = fwd.scale(22).vadd(ship.body.velocity);

    // tiny recoil
    ship.body.applyImpulse(fwd.scale(-0.8), ship.body.position);

    const proj = new Projectile(this.world, this.scene, muzzle, vel);
    proj.owner = ship.isPlayer ? 'player' : 'enemy';
    this.projectiles.push(proj);
  }

  _handleHits(){
    // Very simple hit test: projectile distance to ship body position + radius
    // (We do this for speed and because the ships are compound shapes.)
    const shipRadius = 5.2;

    for (let i=this.projectiles.length-1; i>=0; i--){
      const p = this.projectiles[i];
      const pos = p.body.position;

      const test = (ship, who) => {
        const d = pos.vsub(ship.body.position).length();
        if (d < shipRadius){
          // apply damage
          const base = 8;
          const armour = Object.values(ship.meta).filter(b => b.type === 'armor').length;
          const mitigation = clamp(armour * 0.08, 0, 0.45);
          ship.hp -= base * (1 - mitigation);

          // impact impulse
          const dir = pos.vsub(ship.body.position);
          if (dir.length() > 0.001){
            dir.normalize();
            ship.body.applyImpulse(dir.scale(0.8), pos);
          }
          return true;
        }
        return false;
      };

      const hitPlayer = (p.owner === 'enemy') && test(this.player, 'player');
      const hitEnemy = (p.owner === 'player') && test(this.enemy, 'enemy');
      if (hitPlayer || hitEnemy){
        p.dispose(this.world, this.scene);
        this.projectiles.splice(i,1);
      }
    }

    if (this.player.hp <= 0 || this.enemy.hp <= 0){
      // soft end: respawn both after a short pause
      if (!this._endAt) this._endAt = performance.now() + 900;
      if (performance.now() > this._endAt){
        this._endAt = null;
        this.respawn();
      }
    } else {
      this._endAt = null;
    }
  }
}
