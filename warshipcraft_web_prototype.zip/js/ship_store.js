const STORAGE_KEY = 'warshipcraft_web_ship_v1';

export class ShipStore {
  save(shipJson){
    localStorage.setItem(STORAGE_KEY, JSON.stringify(shipJson));
  }
  load(){
    try{
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return null;
      return JSON.parse(raw);
    }catch(e){
      console.warn('Failed to load ship:', e);
      return null;
    }
  }
  clear(){
    localStorage.removeItem(STORAGE_KEY);
  }
}
