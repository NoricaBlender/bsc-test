import { BuilderApp } from './builder.js';
import { BattleApp } from './battle.js';
import { ShipStore } from './ship_store.js';

const views = {
  home: document.getElementById('homeView'),
  builder: document.getElementById('builderView'),
  battle: document.getElementById('battleView'),
};

function show(name){
  for (const k of Object.keys(views)) views[k].classList.remove('view-active');
  views[name].classList.add('view-active');
}

const btnHome = document.getElementById('btnHome');
const btnBuilder = document.getElementById('btnBuilder');
const btnBattle = document.getElementById('btnBattle');
const homeToBuilder = document.getElementById('homeToBuilder');
const homeToBattle = document.getElementById('homeToBattle');

btnHome.addEventListener('click', () => show('home'));
btnBuilder.addEventListener('click', () => show('builder'));
btnBattle.addEventListener('click', () => show('battle'));
homeToBuilder.addEventListener('click', () => show('builder'));
homeToBattle.addEventListener('click', () => {
  show('battle');
  battle.useDemoShip();
});

const store = new ShipStore();
const builder = new BuilderApp({
  canvas: document.getElementById('builderCanvas'),
  store,
});
const battle = new BattleApp({
  canvas: document.getElementById('battleCanvas'),
  store,
});

builder.init();
battle.init();

// Wiring between builder ↔ battle buttons
document.getElementById('btnUseDemo').addEventListener('click', () => battle.useDemoShip());
document.getElementById('btnUseSaved').addEventListener('click', () => battle.useSavedShip());
document.getElementById('btnRespawn').addEventListener('click', () => battle.respawn());

document.getElementById('btnClear').addEventListener('click', () => builder.clear());
document.getElementById('btnSave').addEventListener('click', () => builder.save());
document.getElementById('btnLoad').addEventListener('click', () => builder.load());

show('home');
