import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { makeKey, parseKey, clamp } from './utils.js';

const GRID = { x: 24, y: 12, z: 6 };      // dimensions
const CELL = 1;
const WATERLINE_Y = 0;

const PARTS = {
  hull:   { mass: 1.0, buoy: 1.2, thrust: 0.0, fire: 0.0, color: 0x5aa2ff },
  armor:  { mass: 2.0, buoy: 0.8, thrust: 0.0, fire: 0.0, color: 0xe6e6e6 },
  engine: { mass: 1.4, buoy: 0.9, thrust: 1.0, fire: 0.0, color: 0xffaa3c },
  cannon: { mass: 1.6, buoy: 0.9, thrust: 0.0, fire: 1.0, color: 0xff5a6b },
};

function defaultShip(){
  // A small, stable demo ship to avoid frustration on first run.
  const blocks = {};
  const baseZ = 0;
  for (let x=8; x<16; x++){
    for (let y=4; y<8; y++){
      blocks[makeKey(x,y,baseZ)] = 'hull';
    }
  }
  blocks[makeKey(9,6,0)] = 'engine';
  blocks[makeKey(10,6,0)] = 'engine';
  blocks[makeKey(11,6,1)] = 'cannon';
  blocks[makeKey(12,6,1)] = 'cannon';
  blocks[makeKey(13,6,1)] = 'cannon';
  return { version: 1, grid: GRID, blocks };
}

export class BuilderApp {
  constructor({canvas, store}){
    this.canvas = canvas;
    this.store = store;

    this.scene = null;
    this.camera = null;
    this.renderer = null;
    this.controls = null;

    this.blocks = {}; // key -> type
    this.activeTool = 'hull';
    this.activeZ = 0;

    this.meshGroups = {}; // type -> InstancedMesh
    this.raycast = { raycaster: new THREE.Raycaster(), mouse: new THREE.Vector2() };
    this.gridPlane = null;

    // UI hooks
    this.toolButtons = Array.from(document.querySelectorAll('.tool'));
    this.layerSlider = document.getElementById('layerSlider');
    this.layerLabel = document.getElementById('layerLabel');

    this.statBlocks = document.getElementById('statBlocks');
    this.statMass = document.getElementById('statMass');
    this.statBuoy = document.getElementById('statBuoy');
    this.statThrust = document.getElementById('statThrust');
    this.statFire = document.getElementById('statFire');
  }

  init(){
    this._initThree();
    this._initUI();
    this.load(true);
    this._resize();
    window.addEventListener('resize', () => this._resize());
    this._loop();
  }

  _initUI(){
    const setTool = (name) => {
      this.activeTool = name;
      for (const b of this.toolButtons){
        b.classList.toggle('tool-active', b.dataset.tool === name);
      }
    };
    this.toolButtons.forEach(b => b.addEventListener('click', () => setTool(b.dataset.tool)));
    setTool('hull');

    this.layerSlider.addEventListener('input', () => {
      this.activeZ = Number(this.layerSlider.value);
      this.layerLabel.textContent = `z=${this.activeZ}`;
      this._updateGridPlane();
    });

    const onPointer = (ev) => {
      const rect = this.canvas.getBoundingClientRect();
      const x = ((ev.clientX - rect.left) / rect.width) * 2 - 1;
      const y = -(((ev.clientY - rect.top) / rect.height) * 2 - 1);
      this.raycast.mouse.set(x,y);

      this.raycast.raycaster.setFromCamera(this.raycast.mouse, this.camera);
      const hit = this.raycast.raycaster.intersectObject(this.gridPlane, false)[0];
      if (!hit) return;

      const p = hit.point.clone().add(new THREE.Vector3(GRID.x*0.5, 0, GRID.y*0.5));
      const gx = clamp(Math.floor(p.x / CELL), 0, GRID.x-1);
      const gy = clamp(Math.floor(p.z / CELL), 0, GRID.y-1);
      const gz = this.activeZ;

      const key = makeKey(gx,gy,gz);
      const remove = (this.activeTool === 'remove') || ev.shiftKey;

      if (remove){
        delete this.blocks[key];
      }else{
        this.blocks[key] = this.activeTool;
      }
      this._syncMeshes();
      this._updateStats();
    };

    // click/tap to place
    this.canvas.addEventListener('pointerdown', (ev) => {
      // ignore when orbiting (right click / middle)
      if (ev.button !== 0) return;
      this.canvas.setPointerCapture(ev.pointerId);
      onPointer(ev);
    });
  }

  _initThree(){
    const scene = new THREE.Scene();
    scene.fog = new THREE.Fog(0x0b1220, 15, 60);

    const camera = new THREE.PerspectiveCamera(55, 1, 0.1, 200);
    camera.position.set(18, 16, 22);

    const renderer = new THREE.WebGLRenderer({
      canvas: this.canvas,
      antialias: true,
      alpha: true,
    });
    renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;

    const controls = new OrbitControls(camera, this.canvas);
    controls.enableDamping = true;
    controls.target.set(GRID.x/2, 2, GRID.y/2);

    const hemi = new THREE.HemisphereLight(0x9bb7ff, 0x08101f, 0.95);
    scene.add(hemi);
    const dir = new THREE.DirectionalLight(0xffffff, 0.85);
    dir.position.set(12,18,8);
    scene.add(dir);

    // water plane (visual only)
    const waterGeo = new THREE.PlaneGeometry(200,200,1,1);
    const waterMat = new THREE.MeshStandardMaterial({ color: 0x0a2a4b, transparent:true, opacity:0.35, metalness:0.0, roughness:0.2 });
    const water = new THREE.Mesh(waterGeo, waterMat);
    water.rotation.x = -Math.PI/2;
    water.position.y = WATERLINE_Y;
    scene.add(water);

    // build area frame
    const frame = new THREE.Box3Helper(new THREE.Box3(
      new THREE.Vector3(0,0,0),
      new THREE.Vector3(GRID.x, GRID.z, GRID.y),
    ), 0x2a3e70);
    frame.position.set(0,0,0);
    scene.add(frame);

    // grid plane used for placement at current Z
    const planeGeo = new THREE.PlaneGeometry(GRID.x, GRID.y, GRID.x, GRID.y);
    const planeMat = new THREE.MeshBasicMaterial({ color: 0x5aa2ff, transparent:true, opacity: 0.06, side: THREE.DoubleSide });
    this.gridPlane = new THREE.Mesh(planeGeo, planeMat);
    this.gridPlane.rotation.x = -Math.PI/2;
    scene.add(this.gridPlane);
    this._updateGridPlane();

    // meshes per part type
    const boxGeo = new THREE.BoxGeometry(CELL, CELL, CELL);
    for (const [type, info] of Object.entries(PARTS)){
      const mat = new THREE.MeshStandardMaterial({ color: info.color, roughness:0.6, metalness:0.1 });
      const im = new THREE.InstancedMesh(boxGeo, mat, GRID.x*GRID.y*GRID.z);
      im.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
      im.count = 0;
      this.meshGroups[type] = im;
      scene.add(im);
    }

    this.scene = scene;
    this.camera = camera;
    this.renderer = renderer;
    this.controls = controls;
  }

  _updateGridPlane(){
    const y = this.activeZ * CELL + (CELL*0.5);
    this.gridPlane.position.set(GRID.x/2, y, GRID.y/2);
  }

  _resize(){
    const rect = this.canvas.getBoundingClientRect();
    const w = Math.max(2, Math.floor(rect.width));
    const h = Math.max(2, Math.floor(rect.height));
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h, false);
  }

  _loop(){
    requestAnimationFrame(() => this._loop());
    this.controls.update();
    this.renderer.render(this.scene, this.camera);
  }

  _syncMeshes(){
    const temp = new THREE.Object3D();
    const perType = {};
    for (const t of Object.keys(PARTS)) perType[t] = [];

    for (const [key, type] of Object.entries(this.blocks)){
      const {x,y,z} = parseKey(key);
      perType[type].push({x,y,z});
    }

    for (const [type, list] of Object.entries(perType)){
      const im = this.meshGroups[type];
      let idx = 0;
      for (const b of list){
        temp.position.set(b.x + 0.5, b.z + 0.5, b.y + 0.5);
        temp.updateMatrix();
        im.setMatrixAt(idx, temp.matrix);
        idx++;
      }
      im.count = idx;
      im.instanceMatrix.needsUpdate = true;
    }
  }

  _updateStats(){
    let blocks = 0, mass = 0, buoy = 0, thrust = 0, fire = 0;
    for (const type of Object.values(this.blocks)){
      blocks++;
      const p = PARTS[type];
      mass += p.mass;
      buoy += p.buoy;
      thrust += p.thrust;
      fire += p.fire;
    }
    this.statBlocks.textContent = String(blocks);
    this.statMass.textContent = mass.toFixed(1);
    this.statBuoy.textContent = buoy.toFixed(1);
    this.statThrust.textContent = thrust.toFixed(1);
    this.statFire.textContent = fire.toFixed(1);
  }

  clear(){
    this.blocks = {};
    this._syncMeshes();
    this._updateStats();
    this.store.clear();
  }

  save(){
    const ship = { version: 1, grid: GRID, blocks: this.blocks };
    this.store.save(ship);
    this._toast('Saved ✔');
  }

  load(allowFallback=false){
    const ship = this.store.load();
    if (ship && ship.blocks){
      this.blocks = ship.blocks;
      this._syncMeshes();
      this._updateStats();
      this._toast('Loaded ✔');
      return;
    }
    if (allowFallback){
      const demo = defaultShip();
      this.blocks = demo.blocks;
      this._syncMeshes();
      this._updateStats();
    }
  }

  getShip(){
    return { version: 1, grid: GRID, blocks: this.blocks };
  }

  _toast(msg){
    // tiny, dependency-free toast
    const el = document.createElement('div');
    el.className = 'pill';
    el.style.position = 'fixed';
    el.style.left = '14px';
    el.style.bottom = '14px';
    el.style.zIndex = '999';
    el.style.pointerEvents = 'none';
    el.textContent = msg;
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 900);
  }
}

export { PARTS, GRID, CELL, WATERLINE_Y, defaultShip };
