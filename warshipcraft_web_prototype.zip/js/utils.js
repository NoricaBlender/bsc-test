export function clamp(x, a, b){
  return Math.max(a, Math.min(b, x));
}

export function lerp(a,b,t){ return a + (b-a)*t; }

export function isTouchDevice(){
  return window.matchMedia && window.matchMedia('(pointer: coarse)').matches;
}

export function nowMs(){ return performance.now(); }

export function makeKey(x,y,z){ return `${x},${y},${z}`; }
export function parseKey(k){
  const [x,y,z] = k.split(',').map(Number);
  return {x,y,z};
}

export function shallowCopy(obj){ return Object.assign({}, obj); }
